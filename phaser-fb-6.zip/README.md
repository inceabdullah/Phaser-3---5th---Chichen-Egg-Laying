# Phaser 3 Facebook Instant Games Examples

The code in this repository is to go with the tutorial located at [http://phaser.io/tutorials/getting-started-facebook-instant-games/](http://phaser.io/tutorials/getting-started-facebook-instant-games/)