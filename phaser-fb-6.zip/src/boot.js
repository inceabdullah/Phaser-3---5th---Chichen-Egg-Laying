var config;
var PixelW = window.innerWidth *  window.devicePixelRatio;
var PixelH = window.innerHeight *  window.devicePixelRatio;

console.log(PixelW);
console.log(PixelH);

FBInstant.initializeAsync().then(function() {

    config = {
        type: Phaser.CANVAS,
        width: PixelW,
        height: PixelH,
        backgroundColor: '#000000',
        physics: {
            default: 'arcade',
            arcade: {
                
                debug: false
            }
        },

        pixelArt: true,

        scene: [ Preloader, GameShare, scene1, scene2 ]
    };

    new Phaser.Game(config);

});
